# drf-dt
Django Rest Framework/DataTables server-side integration
