from django.apps import AppConfig


class DtdrfConfig(AppConfig):
    name = 'dtdrf'
